package com.yash.day2;

public class stringAss {

	public static void main(String[] args) {
		
		System.out.println("Enter String1:");
		String s1="Shannu";
		System.out.println("Enter String2:");
		String s2="hari";
		
		System.out.println("Enter index:");
		int n=2;
		
		char []ch1=s1.toCharArray();
		char []ch2=s2.toCharArray();
		char [] chArr1={' '};
		char chArr2[]={' '};
	    
		for(int i=0;i<n;i++)
		{
			chArr1[i]=ch1[i];
		}
		String ss1=new String(chArr1);
		String ss2=ss1+s2;
		char charArray[]=ss2.toCharArray();
		System.out.print(ss2);
		for(int j=n;j<ch1.length
				;j++)
		{
			System.out.print(ch1[j]);
		}
		
		String newString=ss1+s2+ss2;

	}

}
