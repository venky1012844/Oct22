package com.yash.day2;

public class RepeatedAlphabets {

	public static void main(String[] args) {
		String name="harikrishna";
		char c[]=name.toCharArray();
		for(int i=0;i<c.length;i++) {
			int count=1;
			for(int j=i+1;j<c.length;j++) {
				if(c[i]==c[j]) {
					count++;
				}
			}
			if(count>1) {
				System.out.println(c[i]+"  no: "+count);
			}
		}
	}

}
