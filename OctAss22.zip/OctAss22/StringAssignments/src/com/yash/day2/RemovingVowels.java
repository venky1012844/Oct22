package com.yash.day2;

public class RemovingVowels {

	public static void main(String[] args) {
		String name="harikrishna";
		char c[]=name.toCharArray();
		for(int i=0;i<c.length;i++) {
			if(c[i]=='a'||c[i]=='e'||c[i]=='i'||c[i]=='o'||c[i]=='u') {
				continue;
			}
			System.out.println(c[i]);
		}
	}

}
