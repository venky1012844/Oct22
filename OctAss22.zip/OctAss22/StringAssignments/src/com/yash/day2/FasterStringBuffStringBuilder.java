package com.yash.day2;

public class FasterStringBuffStringBuilder {

	public static void main(String[] args) {
		
		long startingTime = System.currentTimeMillis();  
	     
	     StringBuffer sb = new StringBuffer("yash");  
	     for (int i=0; i<10000; i++){  
	      sb.append("Technology");  
	    }  
	   System.out.println("Time taken by StringBuffer: " + (System.currentTimeMillis() - startingTime) + "ms");  
	   
	   startingTime = System.currentTimeMillis();  
	     StringBuilder sb2 = new StringBuilder("Yash");  
	     for (int i=0; i<10000; i++){  
	     sb2.append("Technology");  
	}  
	   System.out.println("Time taken by StringBuilder: " + (System.currentTimeMillis() - startingTime) + "ms");  
	}

}
