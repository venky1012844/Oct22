package com.yash.day2;

public class StringAssDes {

	public static void main(String[] args) {
		String name = "harikrishna";

		char c[] = name.toCharArray();

		System.out.println("ascending orders are :");

		for (int i = 0; i < c.length; i++) {
			for (int j = i + 1; j < c.length; j++) {
				if (c[i] > c[j]) {
					char temp = c[i];
					c[i] = c[j];
					c[j] = temp;
				}
			}
			System.out.print(c[i]);
		}

		System.out.println("\n descending orders are :");
		for (int i = 0; i < c.length; i++) {
			for (int j = i + 1; j < c.length; j++) {
				if (c[i] < c[j]) {
					char temp = c[i];
					c[i] = c[j];
					c[j] = temp;
				}
			}
			System.out.print(c[i]);
		}
	}

}
