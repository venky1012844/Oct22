package com.yash.task5;

import java.util.Collections;
import java.util.Vector;

public class VectorSoting {

	public static void main(String[] args) {
		Vector<Integer>v=new Vector<Integer>();
		v.add(3);
		v.add(6);
		v.add(1);
		v.add(7);
		System.out.println("sorting vector");
		Collections.sort(v);
		System.out.println(v);
	}

}
