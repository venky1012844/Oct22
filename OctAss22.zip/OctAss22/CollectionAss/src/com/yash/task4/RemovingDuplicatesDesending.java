package com.yash.task4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemovingDuplicatesDesending {

	public static void main(String[] args) {
		List<Integer>list=new ArrayList<>();
		list.add(80);
		list.add(23);
		list.add(45);
		list.add(65);
		list.add(23);
		list.add(13);
		list.add(23);
		list.add(65);
		System.out.println("Before Removing Duplicate:"+list);
		Collections.sort(list,Collections.reverseOrder());
		System.out.println("After removal of duplicate integer decending order:");
		Set<Integer>set=new LinkedHashSet<>(list);
		for(int i:set) {
			System.out.println(" "+i);
		}
	}

}
