package com.yash.task1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AssedingOrder {

	public static void main(String[] args) {
		List<Integer>list=new ArrayList<>();
		list.add(80);
		list.add(23);
		list.add(45);
		list.add(65);
		list.add(13);
		System.out.println("List Before Sorting:"+list);
		Collections.sort(list);
		System.out.println("list After Sorting:"+list);
	}

}
