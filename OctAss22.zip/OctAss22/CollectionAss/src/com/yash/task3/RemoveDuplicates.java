package com.yash.task3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class RemoveDuplicates {

	public static void main(String[] args) {
		List<Integer>list=new ArrayList<>();
		list.add(80);
		list.add(23);
		list.add(45);
		list.add(65);
		list.add(23);
		list.add(13);
		list.add(23);
		list.add(65);
		Collections.sort(list);
		
		System.out.println("Before removing duplicates:"+list);
		
		Set<Integer>setdup=new TreeSet<>(list);
		System.out.println("Afetr removing duplicates:");
		for(int i:setdup) {
			System.out.println(i);
		}
			
	}

}
