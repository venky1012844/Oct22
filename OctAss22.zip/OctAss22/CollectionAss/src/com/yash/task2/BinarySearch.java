package com.yash.task2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BinarySearch {

	public static void main(String[] args) {
		List<Integer>list=new ArrayList<>();
		list.add(80);
		list.add(23);
		list.add(45);
		list.add(65);
		list.add(13);
		int index=Collections.binarySearch(list, 45);
		System.out.println(index);
		index=Collections.binarySearch(list, 10);
		System.out.println(index);
	}

}
