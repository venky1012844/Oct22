package com.yash.task8;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class User{
	private static final String PATTERN = 
			"((?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,14})";
	public static void main(String[] args) throws PasswordFormatException {
		Scanner s=new Scanner(System.in);
		System.out.println("Password must be 8 to 12 in kength");
		System.out.println("Please enter your password:");
		String password=s.next();
		
		Pattern p=Pattern.compile("Password:"+password);
		Matcher m=p.matcher(password);
		if (m.matches()) {
			System.out.println("password"+password+"is valid");
		}
		else {
			 System.out.println("Password "+ password +" is invalid");
			  
			  throw new PasswordFormatException("Password format is Invalid.");
		}
	}

}
