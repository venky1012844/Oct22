package com.yash.task8;

public class PasswordFormatException extends Exception {
	
	public PasswordFormatException(String msg)
	{
		super(msg);
	}

}
