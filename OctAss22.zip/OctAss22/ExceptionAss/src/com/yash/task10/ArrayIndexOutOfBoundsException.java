package com.yash.task10;

public class ArrayIndexOutOfBoundsException extends Exception{

	public ArrayIndexOutOfBoundsException(String msg) {
		super(msg);
	}
}
