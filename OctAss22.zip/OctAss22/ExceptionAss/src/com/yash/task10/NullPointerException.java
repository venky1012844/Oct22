package com.yash.task10;

public class NullPointerException extends Exception{

	public NullPointerException(String msg) {
		super(msg);
	}
}
