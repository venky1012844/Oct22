package com.yash.task4;

public class ItemPurchase extends Exception {

	public ItemPurchase(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	

}
