package com.yash.task2;

public class Salary {

	private double da;
	private double hra;
	private double oa;
	
	public void calculateTotal(int basic) {
		da=0.70*basic;
		hra=0.20*basic;
		oa=0.10*basic;
		
		double total=(basic + da + hra + oa);
		
		System.out.println("Basic Salary:\t" + basic);
        System.out.println("Dearness Allowance:\t" + da);
        System.out.println("House Rent Allowance:\t" + hra);
        System.out.println("Other Allowances:\t" + oa);
        System.out.println("Total Salary is: " + total);
        
	}
}
