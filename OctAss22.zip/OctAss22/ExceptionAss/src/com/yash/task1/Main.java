package com.yash.task1;

public class Main {

	public static void main(String[] args) throws ResultException {
		StudentResult sr=new StudentResult();
		sr.setJava(40);
		sr.setPython(40);
		sr.setSalesforce(40);
		
		Student s=new Student();
		s.setRollno(101);
		s.setSname("venkata hari");
		s.setSaddress("ongole ap");
		s.setSrobj(sr);

		System.out.println(s.toString());
		sr.resultMethod();
	}

}
