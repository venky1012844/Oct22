package com.yash.task11;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

	public static void main(String[] args) throws ParseException {
		String birth="12/05/1999";
		Date dob=new SimpleDateFormat("dd/mm/yyyy").parse(birth);
		String join="02/08/2021";
		Date doj=new SimpleDateFormat("dd/mm/yyyy").parse(join);
		Employee e=new Employee(844,"Harikrishna",25000,"ongole AP",dob,doj);
		System.out.println("====================Employeee Details Are:=================");
		System.out.println(""+e.toString());

	}

}
