package com.yash.task2;

import java.util.Scanner;

public class Rectangle implements Shape{
	int x_breath1,x_breath2,y_breath1,y_breath2;
	int x_length1,x_length2,y_length1,y_length2;
	double length,breath;
	
	@Override
	public double area() {
		Scanner s=new Scanner(System.in);
		
		System.out.println("enter the coordinate length of x1_axis and y1_axis:");
		int x_length1=s.nextInt();
		int y_length1=s.nextInt();
		System.out.println("enter the coordinate length of x2_axis and y2_axis:");
		int x_length2=s.nextInt();
		int y_length2=s.nextInt();
		
		double length1=((x_length2-x_length1)*(x_length2-x_length1))+((y_length2-y_length1)*(y_length2-y_length1));
		length=Math.sqrt(length1);
		
		System.out.println("enter the coordinate breath of x1_axis and y1_axis:");
		int x_breath1=s.nextInt();
		int y_breath1=s.nextInt();
		System.out.println("enter the coordinate breath of x2_axis and y2_axis:");
		int x_breath2=s.nextInt();
		int y_breath2=s.nextInt();
		double breath1=((x_breath2-x_breath1)*(x_breath2-x_breath1))+((y_breath2-y_breath1)*(y_breath2-y_breath1));
		breath=Math.sqrt(breath1);
		
		System.out.println("Length is:"+length+"breath is:"+breath);
		return length*breath;
		}
	public static void main(String[] args) {
		Shape shape=new Rectangle();
		System.out.println(shape.area());

	}


}
