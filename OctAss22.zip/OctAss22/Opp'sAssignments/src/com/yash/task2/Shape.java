package com.yash.task2;

public interface Shape {

	public double area();
}
