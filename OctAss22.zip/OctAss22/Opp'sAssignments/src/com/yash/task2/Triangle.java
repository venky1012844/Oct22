package com.yash.task2;

import java.util.Scanner;

public class Triangle implements Shape {

	int x1side, yside1, xside2, yside2, x3side,y3side;
    double a, b, c;

	@Override
	public double area() {
	    Scanner sc=new Scanner(System.in);
	    
	    System.out.println("Enter the co-ordinate of x1 and y1");
	    x1side=sc.nextInt();
	    yside1=sc.nextInt();
	    
	    System.out.println("Enter the co-ordinate of x2 and y2");
	    xside2=sc.nextInt();
	    yside2=sc.nextInt();
	    
	    System.out.println("Enter the co-ordinate of x3 and y3");
	    x3side=sc.nextInt();
	    y3side=sc.nextInt();



	   double a1=(xside2-x1side)*(xside2-x1side)+(yside2-yside1)*(yside2-yside1);
	    a=Math.sqrt(a1);
	    
	    double b1=(x3side-xside2)*(x3side-xside2)+(y3side-yside2)*(y3side-yside2);
	    b=Math.sqrt(b1);
	    
	    double c1=(x3side-x1side)*(x3side-x1side)+(y3side-yside1)*(y3side-yside1);
	    c=Math.sqrt(c1);
	    
	    double s=((a+b+c)/2);
	  //  System.out.println("Perimeter of Triagle "+(a+b+c));
	    
	double area=s*(s-a)*(s-b)*(s-c);
	    
	    return area;
	}



	public static void main(String[] args) {
	    Shape tringle=new Triangle();
	    System.out.println("Area of Triangle "+tringle.area());
	}


}
	
	
