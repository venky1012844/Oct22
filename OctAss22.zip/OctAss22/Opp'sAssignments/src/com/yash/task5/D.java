package com.yash.task5;

public class D extends C{

	@Override
	public void div(int a, int b) {
		int c=a/b;
		System.out.println("Division:"+c);
		
	}
	public static void main(String[] args) 
	{
		
		CalcAbs cal=new D();
		System.out.println("Sum of two numbers is:");
		cal.sum(3, 5);
		
		System.out.println("sub of two numbers is:");
		cal.sub(46,8);
		
		System.out.println("mul of two numbers is:");
		cal.mul(3,8);
		
		System.out.println("div of two numbers is:");
		cal.div(10,5);
		
		
	}


}
