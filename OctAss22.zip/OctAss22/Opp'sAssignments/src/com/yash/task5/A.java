package com.yash.task5;

public abstract class A extends CalcAbs{

	@Override
	public void sum(int a, int b) {
		int c=a+b;
		System.out.println("Addition :- "+c);
		
	}

}
