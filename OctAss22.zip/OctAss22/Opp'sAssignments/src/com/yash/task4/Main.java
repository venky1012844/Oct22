package com.yash.task4;

public class Main {

	public static void main(String[] args) {
		Area a=new Area();
		a.areaOfRectangle(10, 20, 5);
		a.areaOfSquare(4, 5,8);
		a.areaOfTraingle(3, 4, 5);

	}

}
