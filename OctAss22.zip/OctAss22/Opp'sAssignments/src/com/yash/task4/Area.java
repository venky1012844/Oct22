package com.yash.task4;

public class Area {
double L;
double W;
double H;

public Area(double L, double W, double H) {
	super();

}

public Area() {
	super();
}

void areaOfTraingle(double L, double W, double H) {
	double Traingle = L * W * H;

	System.out.println("print area of tringle-" + Traingle);
}

void areaOfRectangle(double L, double H, double W) {

	double Rectangle = L * W;

	System.out.println("print area of Rectangle-" + Rectangle);
}

void areaOfSquare(double L, double H, double W) {

	double Square = L * L;
	System.out.println("print area of Square-" + Square);

}

}