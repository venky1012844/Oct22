package com.yash.task9;

public class Main {

	public static void main(String[] args) throws CloneNotSupportedException {
		Product p=new Product(1,"apple",10,"Grams");
		Product pr=(Product) p.clone();
		pr.setPname("banana");
		pr.setPrice(200);
		
		System.out.println(p);
		if (pr instanceof Product){
			System.out.println("Objects are same");
		}
	}

}
