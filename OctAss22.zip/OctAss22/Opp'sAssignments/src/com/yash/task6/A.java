package com.yash.task6;

public class A {
	public void getNums(int number) {
		System.out.println("For find 3 , 4 and numbers:");
	}

}
