package com.yash.task6;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class D extends A{

	@Override
	public void getNums(int number) {
		int count = 0;

		int remainder1 = 0;
		int remainder2 = 0;
		int flag;
		while (number > 0) {
			int temp = remainder1;
			remainder1 = number % 10;

			if (temp > remainder1) {
				flag = temp;
				remainder1 = temp;
				temp = flag;

			}

			number = number / 10;
			count++;
			if (count == number) {
				break;

			}
		}
		ArrayList<Integer> al = new ArrayList<>();

		al.add(remainder1);

		List list = al.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());

		System.out.println("The maximum of n numbers" + list);

	}
}
