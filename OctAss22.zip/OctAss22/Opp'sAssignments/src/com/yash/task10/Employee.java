package com.yash.task10;

public class Employee {
	int id;
	public Employee() {
		super();
	}

	public Employee(int id) {
		super();
		this.id=id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + "]";
	}
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
	}
}

