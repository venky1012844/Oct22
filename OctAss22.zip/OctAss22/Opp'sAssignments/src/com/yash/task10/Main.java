package com.yash.task10;

public class Main {

	public static void main(String[] args) {
		Employee e1=new Employee(1001);
		Employee e2=new Employee(1002);
		Employee e3=new Employee(1003);
		Employee e4=new Employee(1004);
		Employee e5=new Employee(1005);
		Employee e6=new Employee(1006);
		
		e2=null;
		e6=null;
		System.gc();
		
		for(int i=1;i<7;i++) {
			String e="e"+i;
			System.out.println(e+":"+e.hashCode());
		}
        System.out.println("e2="+e2);
        System.out.println("e6="+e6);
	}

}
