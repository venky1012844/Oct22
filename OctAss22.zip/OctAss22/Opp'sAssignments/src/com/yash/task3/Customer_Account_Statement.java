package com.yash.task3;

public class Customer_Account_Statement {

	int CAID,amount,deposit_withdrawl;
	String deposite_date;
	Customer CustId;
	
	public Customer_Account_Statement() {}
	
	public Customer_Account_Statement(int caId, Customer custId, int amount, int deposit_withdrawl, String deposit_date) {
		super();
		CAID=caId;
		CustId=custId;
		this.amount=amount;
		this.deposit_withdrawl=deposit_withdrawl;
		this.deposite_date=deposite_date;
	}

	@Override
	public String toString() {
		return "Customer_Account_Statement [CAID=" + CAID + ", amount=" + amount + ", deposit_withdrawl="
				+ deposit_withdrawl + ", deposite_date=" + deposite_date + ", CustId=" + CustId + "]";
	}
	
}
