package com.yash.task3;

public class Main {

	public static void main(String[] args) {
		 System.out.println("===============branch details======================");
		  
		  Branch   branch1 = new Branch(101,"INDIAN","Ongole" );
		  System.out.println("------details of brnach branch1---------------------");
		  System.out.println(branch1);
		  
		  Branch   branch2 = new Branch(1002,"SBI","Vijayawada" );
		  System.out.println("------details of brnach b2-------------------");
		  System.out.println(branch2);
		  
		  Branch   branch3 = new Branch(1003,"IDBI","Guntur" );
		  System.out.println("------details of brnach b3--------------------");
		  System.out.println(branch3);
		  
		System.out.println("=========customer details================");	
		
		Customer cust1 = new Customer(101,30001,"Surya", "bc coleny","15/11/91","12/12/21", branch1);
		System.out.println("=---details of customer c1---------------------------------------");
		System.out.println(cust1);
		
		Customer cust2 = new Customer(102,30002,"Anila", "main road","07/07/91","01/12/22", branch2);
		System.out.println("=---details of customer c2---------------------------------------------");
		System.out.println(cust2);
		
		Customer cust3 = new Customer(103,30002,"Vinay", "Hinjawadi","05/03/95","01/02/20", branch3);
		System.out.println("=---details of customer c3----------------------------------------------------");
		System.out.println(cust3);
		
		
		System.out.println("=============all the details of Customer_Account_Statement====================");
		
		Customer_Account_Statement cas1 = new Customer_Account_Statement(501,cust1, 1200, 500, "24/08/22");
		System.out.println("--------------details of Customer_Account_Statement ca1");
		System.out.println(cas1);
		
		Customer_Account_Statement cas2 = new Customer_Account_Statement(502,cust2, 2000, 700, "22/07/20");
		System.out.println("--------------details of Customer_Account_Statement ca2");
		System.out.println(cas2);
		
		Customer_Account_Statement cas3 = new Customer_Account_Statement(503,cust3, 3000, 800, "21/07/21");
		System.out.println("--------------details of Customer_Account_Statement ca3");
		System.out.println(cas3);

	}

}
