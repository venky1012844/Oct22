package com.yash.task3;

public class Customer {
	int CustId,accno;
	String cname,caddress,cdob,caod;
	Branch bobj;
	public Customer() {} 
	
	public Customer(int CustId,int accno,String cname,String caddress,String cdob,String caod,Branch bobj ){
	super();
	this.CustId=CustId;
	this.accno=accno;
	this.cname=cname;
	this.caddress=caddress;
	this.cdob=cdob;
	this.caod=caod;
	bobj=bobj;
	}

	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", accno=" + accno + ", cname=" + cname + ", caddress=" + caddress
				+ ", cdob=" + cdob + ", caod=" + caod + ", bobj=" + bobj + "]";
	}
	
}
