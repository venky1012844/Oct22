package com.yash.task3;

public class Branch {
	private int bid;
	private String bname;
	private String baddress;
	
	public Branch() {}
	
	public Branch(int bid,String bname,String baddress) {
		super();
		this.bid=bid;
		this.bname=bname;
		this.baddress=baddress;
	}
	@Override
	public String toString() {
		return "Branch [branch_id=" + bid + ", branch_name=" + bname + ", branch_address=" + baddress
				+ "]";
	}

}
