package com.yash.task8;

import java.text.ParseException;

public class Test {

	public static void main(String[] args) throws ParseException {
		Laptop laptop=new Laptop();
		laptop.details();

		Mobile mobile=new Mobile();
		mobile.details();
	}

}
