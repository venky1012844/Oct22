package com.yash.task8;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Electronic {
	private int id;
	private String semiconductorType;
	private Date dateOfManufacturing;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSemiconductorType() {
		return semiconductorType;
	}
	public void setSemiconductorType(String semiconductorType) {
		this.semiconductorType = semiconductorType;
	}
	public Date getDateOfManufacturing() {
		return dateOfManufacturing;
	}
	public void setDateOfManufacturing(Date dateOfManufacturing) {
		this.dateOfManufacturing = dateOfManufacturing;
	}
	public void details() throws ParseException {
		Electronic e =new Electronic();
		e.setId(1001);
		e.setSemiconductorType("copper");
		String date="04/05/2021";
		Date dateOfManufacturing=new SimpleDateFormat("dd/mm/yyyy").parse(date);
		
		System.out.println("Electronic Details:");
		System.out.println("Id:"+e.getId());
		System.out.println("SCT:"+e.getSemiconductorType());
		System.out.println("DOM:"+date);
	}
	

	
}
