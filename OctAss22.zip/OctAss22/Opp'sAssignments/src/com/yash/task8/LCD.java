package com.yash.task8;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LCD extends Electronic{

	public void LCDdetails() throws ParseException {
		Electronic e=new Electronic();
		e.setId(101);
		e.setSemiconductorType("nilon");
		
		String dt = "21/08/2005";
		Date dateofManufacturing = new SimpleDateFormat("dd/MM/yyyy").parse(dt);
		
		System.out.println("Laptop Details...");
		System.out.println("Id -"+e.getId());
		System.out.println("semi-type "+e.getSemiconductorType());
		System.out.println("DOM :-"+dt);
	
	}
}
