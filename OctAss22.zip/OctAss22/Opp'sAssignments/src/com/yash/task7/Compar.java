package com.yash.task7;

public class Compar implements StringCompare {

	@Override
	public void compareString() {
		String st1="Hari";
		String st2="Ammailu";
		
		char ch1[]=st1.toCharArray();
		char ch2[]=st2.toCharArray();
		
		for (int i=0;i<ch1.length;i++) {
			for (int j=0;j<ch2.length;j++) {
				if(ch1[i]==ch2[j]) {
					System.out.println("Compare char is:"+ch1[i]+":"+ch2[j]);
				}
			}
		}
	}
	public static void main(String[] args) {
		StringCompare sc=new Compar();
		sc.compareString();
	}
}
