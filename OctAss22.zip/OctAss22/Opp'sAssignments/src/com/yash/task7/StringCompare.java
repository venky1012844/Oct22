package com.yash.task7;

public interface StringCompare {

	public void compareString();
}
