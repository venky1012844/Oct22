package com.yash.task1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

	public static void main(String[] args) throws ParseException {
		Department[] dept=new Department[2];
		dept[0]=new Department(101,"Hr Department");
		dept[1]=new Department(102,"It Department");
		
		String birth="15/06/1998";
		Date dob=new SimpleDateFormat("dd/mm/yyyy").parse(birth);
		
		String join="02/08/2021";
		Date doj = new SimpleDateFormat("dd/MM/yyyy").parse(join);

		String regist = "11/02/2025";
		Date dor = new SimpleDateFormat("dd/MM/yyyy").parse(regist);
		
		Employee e=new Employee(1,"hari","Andhra", dob, 2500.00, doj, " Indore", dept[1], 98765432,"hari@mail.com");
		Customer c = new Customer(111, "venky", "Ongole", dob, dor, "Pune", 77994114, "Venky@gmail.com");

		System.out.println("Employee Details -");
		 e.EmployeeDetails();
		 
		 System.out.println("Customer Details -");
		 c.CustomerDetails();
		
	}

}
