package com.yash.day1;


public class Pythogaras {
	public static void main(String[] args) {
		int a[] = { 3, 4, 5};

		for (int i = 0; i < a.length - 2; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if ((a[i] * a[i]) + (a[j] * a[j]) == (a[i + 2] * a[i + 2])) {
					System.out.println(a[i] + " " + a[i + 1] + " " + a[i + 2] + " are pythgoras theorem");
			}
		}
	}
  }
}