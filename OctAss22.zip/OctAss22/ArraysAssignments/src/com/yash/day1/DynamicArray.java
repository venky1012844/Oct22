package com.yash.day1;

import java.util.Scanner;

public class DynamicArray {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int[] array=new int[5];
		System.out.println("Enter Array:");
		try {
			for(int i=0;i<6;i++) {
				array[i]=sc.nextInt();
			}
		}catch(Exception e) {
			System.out.print("error try again later");
		}

	}
}
