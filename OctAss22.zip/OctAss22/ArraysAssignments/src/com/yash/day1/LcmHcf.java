package com.yash.day1;

public class LcmHcf {

	public static void main(String[] args) {
		int array[]= {10,35};
		for(int i=0;i<array.length;i++) {
			for(int j=i+1;j<array.length;j++) {
				int temp;
				int temp1=array[i];
				int temp2=array[j];
				while(temp2!=0) {
					temp=temp2;
					temp2=temp1 % temp2;
					temp1 = temp;
				}
				int hcf = temp1;
				int lcm = (array[i] * array[j]) / hcf;

				System.out.println("The HCF of " + array[i] + " and " + array[j] + "=" + hcf);
				System.out.println("The LCM of " + array[i] + " and " + array[j] + "=" + lcm);
				System.out.println(" ");
			}
		}

	}

}
