package com.yash.day1;

public class SortByLength {

	public static void main(String[] args) {
		String array[] = { "hello","venkata","your name","is","i know ","guru"};

        String temp;
        for(int i=0;i<array.length;i++) {
        	for(int j=i+1;j<array.length;j++) {
        		if(array[i].length()>array[j].length()) {
        			temp=array[i];
        			array[i]=array[j];
        			array[j]=temp;
        		}
        	}
        	System.out.println(array[i]);
        }

	}

}

