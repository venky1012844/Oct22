package com.yash.day1;

public class EvenOddPrimePerfect {

	public static void main(String[] args) {
		int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 10,28};

		int count = 0;
		int count1 = 0;
		int count2 = 0;
		int perfect = 0;
		int prime = 1;

		for (int i = 0; i < array.length; i++) {

			if (array[i] % 2 == 0) {
				count++;
			}
			if (array[i] % 2 != 0) {
				count1++;
			}

			for (int j = 2; j <= array.length - 1; j++) {

				if (array[i] % j == 0) {
					prime++;
				}

			}

			if (prime == 1) {

				count2++;

			}

			int sum = 0;
			int no = array[i];
			for (int m = 1; m < no; m++) {

				if (no % m == 0) {

					sum = sum + m;

				}

			}

			if (sum == no) {

				perfect++;

			}

		}

		System.out.println("even no :-" + count);
		System.out.println("odd no :-" + count1);
		System.out.println("prime no :-" + count2);
		System.out.println("perfect no :-" + perfect);
	}
}
		

