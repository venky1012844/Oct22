package com.yash.day1;

public class ThirdMaxNumber {

	public static void main(String[] args) {
		int temp,size;
		int array[]= {98,87,56,11,22,54,89};
		size=array.length;
		for(int i=0;i<size;i++) {
			for (int j=i+1;j<size;j++) {
				if(array[i]>array[j]) {
					temp=array[i];
					array[i]=array[j];
					array[j]=temp;
				}
			}
		}
		System.out.println("third max number is:"+array[size-3]);

	}

}
