package com.yash.day1;

public class RemoveNonPalindrom {

	public static void main(String[] args) {
		String[] array = { "akka", "hari", "ama", "madam", "vikatakavi" };

		for (int i = 0; i < array.length; i++) {
			if (array[i].equalsIgnoreCase(isPalindrome(array[i]))) {
				System.out.print(array[i] + " ");
			}
		}
	}
	public static String isPalindrome(String reverse) {
		String temp = reverse;
		String rev = "";
		for (int i = temp.length() - 1; i >= 0; i--) {
			rev = rev + temp.charAt(i);
		}
		return rev;
	}
}
